from math import sqrt

def fun1(x, y, z):
    print('sum:',x + y + z)
    
def fun2(x = 2, y = 2, z = 2):
    vec = sqrt(x**2 + y**2 + z**2)
    return vec

def fun3():
    while True:
        try:
            val = int(input('Please enter the number from 1 to 10: '))
            if (val < 1 or val > 10):
                print('The number must be between 1 and 10.')
                continue
            if (val == 7):
                print('You won')
                break
            elif (val > 7):
                print('The number is too high')
            elif (val < 7):
                print('The number is too low')
        except:
             print('Please enter a number :)')    
       