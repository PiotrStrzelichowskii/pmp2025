def func1(string):
    string = string[::-1]
    print(string)
    
def func2(list):
    for val in list:
        print(val, end = "\n")
        
def func3(*args):
    return sum(args)

def func4(value, data):
    return value in data

    